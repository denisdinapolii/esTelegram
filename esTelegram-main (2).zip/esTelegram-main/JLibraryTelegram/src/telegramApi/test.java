/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author di_napoli_denis
 */
public class test {
    
    String path;
    
    public test(String path) {
        this.path=path;
    }
    
    public String getMe() throws IOException, SAXException, ParserConfigurationException{
        path=path+"/getMe";
        
        URL url = new URL(path);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader rd = new BufferedReader(new InputStreamReader(url.openStream()));
        return read(rd);
    }
    
    private static String read(Reader rd) throws IOException { //private static String read(BufferedReader rd) throws IOException
        /*String str="";
        while (rd.read()!= -1)            
            str+= rd.readLine();
        rd.close();
        return str;*/
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
          sb.append((char) cp);
        }
        return sb.toString();
    }

}
