/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progtelegram;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.xml.parsers.ParserConfigurationException;
import org.codehaus.jackson.map.DeserializationConfig;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xml.sax.SAXException;
import telegramApi.*;
import org.codehaus.jackson.map.ObjectMapper;
/**
 *
 * @author di_napoli_denis
 */
public class ProgTelegram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
        // TODO code application logic here
        /*test test= new test();
        test.print();
        
        String jsonString = "{nome: 'mario', messaggio:[ciao ,bro]} " ; //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        String nome = obj.getString("nome");
        
        
        System.out.println(nome);
        JSONArray arr = obj.getJSONArray("messaggio"); // notice that `"posts": [...]`
        for (int i = 0; i < arr.length(); i++)
        {
            String messaggio = arr.getString(i);
            System.out.println(messaggio);
        }
        */
        String path="https://api.telegram.org/bot";
        String httpApi="5286864698:AAFET68a1EHHnWQZhDDyrZTB8Mzdts7ncMk";
        
        test t= new test(path+httpApi);
        
        
        JSONObject obj= new JSONObject(t.getMe());
        boolean okAtt= obj.getBoolean("ok");// ok=>true
        
        JSONObject obj2= obj.getJSONObject("result");
        
        
        long id=(long)obj2.get("id");
        boolean is_bot=(boolean)obj2.get("is_bot");
        String first_name=(String) obj2.get("first_name");
        String username=(String)obj2.get("username");
        boolean can_join_groups=(boolean)obj2.get("can_join_groups"); 
        boolean can_read_all_group_messages=(boolean)obj2.get("can_read_all_group_messages");
        boolean supports_inline_queries=(boolean)obj2.get("supports_inline_queries");
        
        
        result res=new result( (int) id,is_bot,first_name,username,can_join_groups,can_read_all_group_messages,supports_inline_queries);
        ok ok=new ok(okAtt, res);
        
        String str=ok.toString();
        
        System.out.println(ok.toString());
        
        
        
        
        
    }
    
}
