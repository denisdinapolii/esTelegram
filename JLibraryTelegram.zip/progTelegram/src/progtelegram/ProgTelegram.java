/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progtelegram;
import org.json.JSONArray;
import org.json.JSONObject;
import telegramApi.*;
/**
 *
 * @author di_napoli_denis
 */
public class ProgTelegram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        test test= new test();
        test.print();
        
        String jsonString = "{nome: 'mario', messaggio:[ciao ,bro]} " ; //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        String nome = obj.getString("nome");
        
        
        System.out.println(nome);
        JSONArray arr = obj.getJSONArray("messaggio"); // notice that `"posts": [...]`
        for (int i = 0; i < arr.length(); i++)
        {
            String messaggio = arr.getString(i);
            System.out.println(messaggio);
        }
    }
    
}
