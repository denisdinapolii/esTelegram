/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

/**
 *
 * @author denis
 */
public class result {
    private long id;
    private boolean is_bot;
    private String first_name;
    private String username;
    private boolean can_join_groups; 
    private boolean can_read_all_group_messages;
    private boolean supports_inline_queries;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isIs_bot() {
        return is_bot;
    }

    public void setIs_bot(boolean is_bot) {
        this.is_bot = is_bot;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isCan_join_groups() {
        return can_join_groups;
    }

    public void setCan_join_groups(boolean can_join_groups) {
        this.can_join_groups = can_join_groups;
    }

    public boolean isCan_read_all_group_messages() {
        return can_read_all_group_messages;
    }

    public void setCan_read_all_group_messages(boolean can_read_all_group_messages) {
        this.can_read_all_group_messages = can_read_all_group_messages;
    }

    public boolean isSupports_inline_queries() {
        return supports_inline_queries;
    }

    public void setSupports_inline_queries(boolean supports_inline_queries) {
        this.supports_inline_queries = supports_inline_queries;
    }

    public result(int id, boolean is_bot, String first_name, String username, boolean can_join_groups, boolean can_read_all_group_messages, boolean supports_inline_queries) {
        this.id = id;
        this.is_bot = is_bot;
        this.can_join_groups = can_join_groups;
        this.can_read_all_group_messages = can_read_all_group_messages;
        this.supports_inline_queries = supports_inline_queries;
        this.first_name = first_name;
        this.username = username;
    }
    
    
    @Override
    public String toString(){
        String s="ID:"+id;
        s+="\nis_bot:"+is_bot;
        s+="\nfirst_name:"+first_name;
        s+="\nusername:"+username;
        s+="\ncan_join_groups:"+can_join_groups;
        s+="\ncan_read_all_group_messages:"+can_read_all_group_messages;
        s+="\nsupports_inline_queries:"+supports_inline_queries;
        return s;
    }

}
