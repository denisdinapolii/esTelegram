/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

/**
 *
 * @author denis
 */
public class messageBot {
    
    public boolean ok;
    public Result result;
    
    @Override
    public String toString(){
        return result.toString();
    }
    
    public class From{
    public long id;
    public boolean is_bot;
    public String first_name;
    public String username;
    
    @Override
    public String toString(){
        return "Dal bot: "+username+"\n";
    }
}

public class Chat{
    public int id;
    public String first_name;
    public String type;
    
    @Override 
    public String toString(){
        return "Per: "+first_name+"\n";
    }
}

public class Result{
    public int message_id;
    public From from;
    public Chat chat;
    public int date;
    public String text;
    
    @Override
    public String toString(){
        return from.toString()+chat.toString()+"Scrive: "+text;
    }
}

}
