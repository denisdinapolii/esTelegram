/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.util.ArrayList;

/**
 *
 * @author di_napoli_denis
 */
public class mainObjMessage {
    public boolean ok;
    public ArrayList<Result> result;
    
    @Override
    public String toString(){
        String str="";
        if (result.size()>=1) {
            for (int i = 0; i < result.size(); i++) {
                str+="\n"+result.get(i).toString();
            }
        }
        
        return str;
    }
    //classe 
    public class From{

        public int id;
        public boolean is_bot;
        public String first_name;
        public String language_code;
        
        @Override
        public String toString() {
            String str="\n\tid: "+id;
            str+="\n\tfirst_name: "+first_name;
            return str;
        }
    }
    
    //classe
    public class Chat{
        public int id;
        public String first_name;
        public String type;
        @Override
        public String toString(){
            String str="\n\tid: "+id;
            str+="\n\tfirst_name: "+first_name;
            str+="\n\ttype: "+type;
            return str;
        }
    }

    //classe
    public class Entity{

        public int offset;
        public int length;
        public String type;
    }

    public class Location {
        public double latitude;
        public double longitude;
        
        @Override
        public String toString(){
            String str="\tLatitudine: "+latitude;
            str+="\n\tLongitudine: "+longitude;
            return str;
        }
    }
    
    //classe
    public class Message{
        public int message_id;
        public From from;
        public Chat chat;
        public int date;
        public String text;
        public ArrayList<Entity> entities;
        public Location location;
        
        
        @Override
        public String toString(){
            String str="";
            str+="\nfrom:"+from.toString();
            str+="\nchat:"+chat.toString();
            str+="\ntext:\t"+text;
            try {
                str+="\nCoordinate: \n"+location.toString();
            } catch (Exception e) {
            }
            return str;
        }
    }

    //classe
    public class Result{

        public int update_id;
        public Message message; 
        @Override
        public String toString() {
            String str="";
            str+=message.toString()+"\n";
            return str;
        }
        
        
    }


}
