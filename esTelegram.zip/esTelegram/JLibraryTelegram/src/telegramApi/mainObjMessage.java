/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.util.ArrayList;

/**
 *
 * @author di_napoli_denis
 */
public class mainObjMessage {
    public boolean ok;
    public ArrayList<Result> result;
        
    public mainObjMessage(){}
     
    public mainObjMessage(boolean ok, ArrayList<Result> result) {
        this.ok = ok;
        this.result = result;
    }
    
    @Override
    public String toString(){
        String str="\nok:"+ok;
        if (result.size()>=1) {
            for (int i = 0; i < result.size(); i++) {
                str+="\n"+result.get(i).toString();
            }
        }
        
        return str;
    }
    //classe 
    public class From{

        public int id;
        public boolean is_bot;
        public String first_name;
        public String language_code;

        public From(int id, boolean is_bot, String first_name, String language_code) {
            this.id = id;
            this.is_bot = is_bot;
            this.first_name = first_name;
            this.language_code = language_code;
        }
        
        public From(){}
        
        
        @Override
        public String toString() {
            String str="\n\tid:"+id;
            str+="\n\tis_bot"+is_bot;
            str+="\n\tfirst_name"+first_name;
            str+="\n\tlanguage_code"+language_code;
            return str;
        }
    }
    
    //classe
    public class Chat{
        public int id;
        public String first_name;
        public String type;
        
        public Chat(){}
        
        public Chat(int id, String first_name, String type) {
            this.id = id;
            this.first_name = first_name;
            this.type = type;
        }
        @Override
        public String toString(){
            String str="\n\tid:"+id;
            str+="\n\tfirst_name"+first_name;
            str+="\n\ttype"+type;
            return str;
        }
    }

    //classe
    public class Entity{

        public int offset;
        public int length;
        public String type;
        
        public Entity(){}
        public Entity(int offset, int length, String type) {
            this.offset = offset;
            this.length = length;
            this.type = type;
        }
        
        
        @Override
        public String toString(){
            String str="\n\toffset:"+offset;
            str+="\n\tlength"+length;
            str+="\n\ttype"+type;
            return str;
        }
    }

    //classe
    public class Message{

        public Message(int message_id, From from, Chat chat, int date, String text, ArrayList<Entity> entities) {
            this.message_id = message_id;
            this.from = from;
            this.chat = chat;
            this.date = date;
            this.text = text;
            this.entities = entities;
        }

        public Message(int message_id, From from, Chat chat, int date, String text) {
            this.message_id = message_id;
            this.from = from;
            this.chat = chat;
            this.date = date;
            this.text = text;
        }
        
        
        
        public int message_id;
        public From from;
        public Chat chat;
        public int date;
        public String text;
        public ArrayList<Entity> entities;
        
        public Message(){}
        
        @Override
        public String toString(){
            String str="\nmessage_id:"+message_id;
            str+="\nfrom:"+from.toString();
            str+="\nchat:"+chat.toString();
            str+="\ndate:"+date;
            str+="\ntext:"+text;
            if(entities!=null){
                for (int i = 0; i < entities.size(); i++) {
                    str+="\nentity:"+entities.get(i).toString();
                }
            }
            return str;
        }
    }

    //classe
    public class Result{

        public int update_id;
        public Message message;
        
        public Result(int update_id, Message message) {
            this.update_id = update_id;
            this.message = message;
        }
        public Result(){}

        
        
        @Override
        public String toString() {
            String str="\nupdate_id"+update_id+"\n";
            str+=message.toString()+"\n";
            return str;
        }
        
        
    }


}
