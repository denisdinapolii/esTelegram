/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

/**
 *
 * @author denis
 */
public class ok {
    private boolean ok;
    private result result;
    
    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public result getResult() {
        return result;
    }

    public void setResult(result result) {
        this.result = result;
    }
    
    
    public ok(boolean ok, result res) {
        this.ok = ok;
        this.result = result;
    }

    @Override
    public String toString() {
        String s="Ok:"+ok+"\n";
        s+=result.toString();
        return s;
    }
    
    
    
}
