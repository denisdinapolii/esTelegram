/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.util.Date;

/**
 *
 * @author denis
 */
public class reversegeocode {
    public result result;
    public addressparts addressparts;
    public Date timestamp;
    public String attribution;
    public String querystring;
    public String text;
    
        public class result { 
            public int place_id;
            public String osm_type;
            public int osm_id;
            public String ref;
            public double lat;
            public double lon;
            public String boundingbox;
            public int place_rank;
            public int address_rank;
            public String text;
    }

    public class addressparts { 
            public String road;
            public String neighbourhood;
            public String suburb;
            public String village;
            public String city;
            public String county;
            public String state;
            public int postcode;
            public String country;
            public String country_code;
    }
}
