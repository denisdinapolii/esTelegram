/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import com.google.maps.*;

/**
 *
 * @author di_napoli_denis
 */
public class test {
    
    String path;
    
    public test(String path) {
        this.path=path;
    }
    
    public String sendMessage(String chat_id, String text) throws IOException{
        String pathTemp=path+"/sendMessage?chat_id="+chat_id+"&text="+text;
        
        return connStream(pathTemp);
    }
    
    public String getMe() throws IOException{
        String pathTemp=path+"/getMe";
        
        return connStream(pathTemp);
    }
    
    public void searchPos(mainObjMessage.Location location){
       /* String str="";
        com.google.maps.GeoApiContext apiContext= new GeoApiContext()
        return str;*/
    }
    
    public String getUpdates() throws MalformedURLException, IOException{
        String pathTemp=path+"/getUpdates";
        
        return connStream(pathTemp);
    }
    
    private String connStream(String pathTemp) throws IOException{
        URL url= new URL(pathTemp);
        HttpURLConnection con= (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader rd=new BufferedReader(new InputStreamReader(url.openStream()));
        return read(rd);
    }
    
    private static String read(Reader rd) throws IOException { //private static String read(BufferedReader rd) throws IOException
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
          sb.append((char) cp);
        }
        return sb.toString();
        
    }

}
