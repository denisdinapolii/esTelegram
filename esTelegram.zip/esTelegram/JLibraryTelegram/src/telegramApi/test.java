/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegramApi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author di_napoli_denis
 */
public class test {
    
    String path;
    
    public test(String path) {
        this.path=path;
    }
    
    public String sendMessage(String chat_id, String text) throws IOException{
        String pathTemp=path+"/sendMessage?chat_id="+chat_id+"&text="+text;
        
        return connStream(pathTemp);
    }
    
    public String getMe() throws IOException{
        String pathTemp=path+"/getMe";
        
        return connStream(pathTemp);
    }
    
    public String getTextElementFromXML(Document doc, String out){
        NodeList list=doc.getElementsByTagName(out);
        Element el= (Element) list.item(0);
        return el.getTextContent();
    }
    
   
    
    
    
    public String coordsToDistance(Coordinate c1, Coordinate c2){
            double earthRadius = 6371000; //meters
            double dLat = Math.toRadians(c2.y-c1.y);
            double dLng = Math.toRadians(c2.x-c1.x);
            double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                       Math.cos(Math.toRadians(c1.y)) * Math.cos(Math.toRadians(c2.y)) *
                       Math.sin(dLng/2) * Math.sin(dLng/2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            float dist = (float) (earthRadius * c);

            return String.valueOf(dist);
    }
    
    public Document createDocXML(String path) {
        Document doc=null;
        try {
            URL url= new URL(path);
            DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
            DocumentBuilder builder= factory.newDocumentBuilder();
            return doc = builder.parse(url.openStream());
        } catch (MalformedURLException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    public String searchPos(mainObjMessage.Location location) throws IOException{
        String linkMap="https://nominatim.openstreetmap.org/reverse?lat="+location.latitude+"&lon="+location.longitude; //https://nominatim.openstreetmap.org/reverse?lat=45.638752&lon=9.19623
       URL url= new URL(linkMap);
       String str="";
       DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
        try {
           DocumentBuilder DocumentBuilder = factory.newDocumentBuilder();
           Document doc= DocumentBuilder.parse(url.openStream());
            NodeList list= doc.getElementsByTagName("result");
            str=list.item(0).getTextContent(); 
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
       return str;
    }
    
    public String searchPos(String citta){
        if(!(citta.equals(""))){
            String link="https://nominatim.openstreetmap.org/search?q="+citta+"&format=xml&addressdetails=1";
            DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            
            try {
                builder = factory.newDocumentBuilder();
                URL url= new URL(link);
                Document doc= builder.parse(url.openStream());
                NodeList place=doc.getElementsByTagName("place");
                Element elPlace=(Element)place.item(0);
                citta+=";"+elPlace.getAttribute("lat");
                citta+=";"+elPlace.getAttribute("lon");
                
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (MalformedURLException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SAXException ex) {
                Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return citta;
    }
    
    public String getUpdates() throws MalformedURLException, IOException{
        String pathTemp=path+"/getUpdates";
        
        return connStream(pathTemp);
    }
    
    public String toStringJSONObject(JSONObject obj){
        String str="";
        JSONArray keys= obj.names(); //keys
        for (int i = 0; i < keys.length(); i++) {
            str+=keys.getString(i);
            str+=obj.getString(keys.getString(i))+"\n";
        }
        return str;
    }
    
    private String connStream(String pathTemp) throws IOException{
        URL url= new URL(pathTemp);
        HttpURLConnection con= (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        BufferedReader rd=new BufferedReader(new InputStreamReader(url.openStream())); 
        return read(rd);
    }
    
    private static String read(Reader rd) throws IOException { //private static String read(BufferedReader rd) throws IOException
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
          sb.append((char) cp);
        }
        return sb.toString();
        
    }
    
    
    //in JFrame
    
    private boolean isNewMessage(int IDMessage){
        try {
            File file= new File("posizioneUtenti.csv");
            if (!file.exists())
                file.createNewFile();
            Scanner reader= new Scanner(file);
            String data="";
            String[] vStr;
            while(reader.hasNextLine()){
                data=reader.nextLine();
                vStr=data.split(";"); 
                if (Integer.valueOf(vStr[vStr.length-1])<IDMessage)
                    return true;
                else
                    return false;
            }   } catch (IOException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    private boolean writeFile(String citta){
        try {
            FileWriter fw = null;
            String txt = searchPos(citta);
            fw = new FileWriter("posizioneUtenti.csv");
            String[] vect=txt.split("-");
            fw.write(vect[0]+"\n");
            fw.close();
            return Boolean.parseBoolean(vect[1]);
        } catch (IOException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
            return false;
    }
    
    
    private String searchPosInFile(String str){
        try {
            //str città; lat; lon; chat_id; update_id
            String txt="";
            File file= new File("posizioneUtenti.csv");
            if (!file.exists())
                file.createNewFile();
            Scanner reader= new Scanner(file);
            String data="";
            String[] vect= str.split(";");  //vect[]= città; lat; lon; chat_id; update_id
            String[] vStr;
            boolean sent=false;
            if (reader.hasNextLine()) {
                while(reader.hasNextLine()){
                    data=reader.nextLine();                    // CODICE_SU_STR  32267880
                    vStr=data.split(";");                      // CODICE_SU_FILE 32267878               RIGA DA AGGIUNGERE 76               <       RIGA SU FILE 78
                    if (!data.contains(vect[vect.length-2]) || (data.contains(vect[vect.length-2]) && Integer.parseInt(vect[vect.length-1]) < Integer.parseInt(vStr[vStr.length-1])))    
                        txt+=data+"\n";
                    else 
                        sent=true;
                }
            }else
                sent=true;
            
            if (sent){
                txt+=str;
            }
            return txt+"-"+sent;
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(test.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
